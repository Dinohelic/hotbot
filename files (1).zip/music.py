import asyncio
from typing import Optional

import discord
from discord.ext import commands
from yt_dlp import YoutubeDL

YTDL_FORMAT_OPTIONS = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "default_search": "ytsearch",
    "source_address": "0.0.0.0",  # avoids some IPv6 lookup issues
}

FFMPEG_OPTIONS = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}

ytdl = YoutubeDL(YTDL_FORMAT_OPTIONS)


class Track:
    def __init__(self, data: dict):
        self.title = data.get("title", "Unknown title")
        self.url = data.get("url")               # direct stream URL for FFmpeg
        self.webpage_url = data.get("webpage_url")
        self.duration = data.get("duration")


class GuildMusicState:
    def __init__(self):
        self.queue: list[Track] = []
        self.voice_client: Optional[discord.VoiceClient] = None
        self.current: Optional[Track] = None


class Music(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.states: dict[int, GuildMusicState] = {}

    def get_state(self, guild_id: int) -> GuildMusicState:
        if guild_id not in self.states:
            self.states[guild_id] = GuildMusicState()
        return self.states[guild_id]

    async def search(self, query: str) -> Track:
        loop = asyncio.get_running_loop()
        data = await loop.run_in_executor(
            None, lambda: ytdl.extract_info(query, download=False)
        )
        if "entries" in data:  # came from a ytsearch — take the first hit
            data = data["entries"][0]
        return Track(data)

    def play_next(self, guild: discord.Guild):
        state = self.get_state(guild.id)
        if not state.queue:
            state.current = None
            return

        track = state.queue.pop(0)
        state.current = track
        source = discord.FFmpegPCMAudio(track.url, **FFMPEG_OPTIONS)

        def after_playing(error: Optional[Exception]):
            if error:
                print(f"Player error: {error}")
            self.play_next(guild)

        state.voice_client.play(source, after=after_playing)

    @commands.command(name="join")
    async def join(self, ctx: commands.Context):
        if ctx.author.voice is None or ctx.author.voice.channel is None:
            await ctx.send("Join a voice channel first.")
            return

        channel = ctx.author.voice.channel
        state = self.get_state(ctx.guild.id)

        if state.voice_client is None or not state.voice_client.is_connected():
            state.voice_client = await channel.connect()
        else:
            await state.voice_client.move_to(channel)

        await ctx.send(f"Joined **{channel.name}**.")

    @commands.command(name="play")
    async def play(self, ctx: commands.Context, *, query: str):
        if ctx.author.voice is None or ctx.author.voice.channel is None:
            await ctx.send("Join a voice channel first.")
            return

        state = self.get_state(ctx.guild.id)

        if state.voice_client is None or not state.voice_client.is_connected():
            state.voice_client = await ctx.author.voice.channel.connect()

        async with ctx.typing():
            try:
                track = await self.search(query)
            except Exception as e:
                await ctx.send(f"Couldn't find that: {e}")
                return

        state.queue.append(track)
        await ctx.send(f"Queued **{track.title}**")

        if not state.voice_client.is_playing() and state.current is None:
            self.play_next(ctx.guild)

    @commands.command(name="skip")
    async def skip(self, ctx: commands.Context):
        state = self.get_state(ctx.guild.id)
        if state.voice_client and state.voice_client.is_playing():
            state.voice_client.stop()  # triggers after_playing -> play_next
            await ctx.send("Skipped.")
        else:
            await ctx.send("Nothing is playing.")

    @commands.command(name="stop")
    async def stop(self, ctx: commands.Context):
        state = self.get_state(ctx.guild.id)
        state.queue.clear()
        if state.voice_client:
            await state.voice_client.disconnect()
            state.voice_client = None
        state.current = None
        await ctx.send("Stopped and left the voice channel.")

    @commands.command(name="queue")
    async def show_queue(self, ctx: commands.Context):
        state = self.get_state(ctx.guild.id)
        if not state.queue and not state.current:
            await ctx.send("Queue is empty.")
            return

        lines = []
        if state.current:
            lines.append(f"**Now playing:** {state.current.title}")
        for i, track in enumerate(state.queue, start=1):
            lines.append(f"{i}. {track.title}")
        await ctx.send("\n".join(lines))


async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
