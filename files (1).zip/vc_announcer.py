import discord
from discord.ext import commands

# Replace with the ID of the text channel where join announcements should post.
# (Right-click the channel in Discord with Developer Mode on -> Copy Channel ID)
ANNOUNCE_CHANNEL_ID = 123456789012345678


class VCAnnouncer(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ):
        # Ignore bots so the bot doesn't announce itself (or other bots) joining
        if member.bot:
            return

        joined_a_channel = before.channel is None and after.channel is not None
        switched_channel = (
            before.channel is not None
            and after.channel is not None
            and before.channel.id != after.channel.id
        )

        # Only fire on an actual join/switch — not on mute/deafen toggles or leaves
        if not (joined_a_channel or switched_channel):
            return

        channel = self.bot.get_channel(ANNOUNCE_CHANNEL_ID)
        if channel is None:
            return

        await channel.send(
            f"🔊 **{member.display_name}** joined **{after.channel.name}**"
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(VCAnnouncer(bot))
